# EventoAI GPT Bridge

A Flask-based web application that processes and analyzes event data using OpenAI's GPT-5 model. The system receives event data, sends it to GPT for intelligent analysis, and provides insights including event categorization, priority levels, and actionable recommendations through a web dashboard.

## Features

- **Event Webhook Receiver**: POST endpoint to receive events from EventoAI
- **GPT-5 Integration**: Intelligent event analysis using OpenAI's latest model
- **Real-time Dashboard**: View processed events with insights and recommendations
- **Proper Error Handling**: Clear error messages and HTTP status codes
- **Auto-refresh**: Dashboard updates every 10 seconds automatically

## API Endpoints

### POST /api/webhook
Receive and process events from EventoAI.

**Request Body:**
```json
{
  "event_name": "user_signup",
  "user_id": "12345",
  "timestamp": "2025-10-04T20:00:00Z",
  "metadata": { ... }
}
```

**Response (Success):**
```json
{
  "success": true,
  "message": "Event processed successfully",
  "event_id": 1,
  "analysis": {
    "event_type": "User Registration",
    "priority": "medium",
    "summary": "New user signup detected",
    "insights": ["User activity increased", "..."],
    "recommendations": ["Send welcome email", "..."]
  }
}
```

**Response (Error):**
```json
{
  "success": false,
  "error": "OpenAI API key is invalid or missing. Please check your OPENAI_API_KEY secret."
}
```

### POST /api/process
Manually process an event without storing it.

### GET /api/events
Retrieve all processed events.

### GET /api/health
Health check endpoint with API key status.

## Setup

1. **OpenAI API Key**: The application requires a valid OpenAI API key. Make sure your `OPENAI_API_KEY` secret is configured correctly.

2. **Test the webhook**: Send a POST request to `/api/webhook` with event data.

3. **View results**: Open the dashboard at the root URL (`/`) to see processed events.

## Testing

Test the webhook with curl:

```bash
curl -X POST https://your-app-url/api/webhook \
  -H "Content-Type: application/json" \
  -d '{
    "event_name": "test_event",
    "user_id": "user_123",
    "timestamp": "2025-10-04T20:00:00Z",
    "details": "Test event data"
  }'
```

## Important Notes

- **API Key**: The current OpenAI API key may need to be verified. If you see 401 errors, please check that your API key is valid at https://platform.openai.com/account/api-keys
- **In-Memory Storage**: Events are stored in memory and will be lost when the application restarts
- **GPT-5 Model**: The application uses OpenAI's GPT-5 model (released August 7, 2025)

## Dashboard Features

- **Total Events Counter**: Shows number of processed events
- **Status Indicator**: Displays system status
- **Event Cards**: Each event shows:
  - Event ID and priority badge
  - Event type and timestamp
  - Summary of the event
  - AI-generated insights
  - Actionable recommendations
  - Original event data (toggle to view)

## Next Steps

For production use, consider:
- Adding persistent storage (PostgreSQL/MongoDB)
- Implementing authentication for webhook endpoints
- Adding async/background processing for better performance
- Setting up a production WSGI server (Gunicorn)
